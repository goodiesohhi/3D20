#pragma once

u32 GetCtrBlockSize(u8 flag);
u8 GetCtrBlockSizeFlag(u32 size);