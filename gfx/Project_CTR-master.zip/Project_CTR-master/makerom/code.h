#pragma once

int BuildExeFsCode(ncch_settings *ncchset);