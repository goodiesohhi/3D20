#pragma once

void EvaluateRSF(rsf_settings *rsf, ctr_yaml_context *ctx);
void free_RsfSettings(rsf_settings *set);