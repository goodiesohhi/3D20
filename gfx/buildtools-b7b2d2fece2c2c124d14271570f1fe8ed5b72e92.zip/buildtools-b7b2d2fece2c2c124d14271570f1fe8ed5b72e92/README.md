# buildtools

Common build tools for C/C++ projects. Supports PC and 3DS targets.

Requires some form of the zip/unzip commands. When embedding binary files, xxd is required as well.

Credit for 3DS homebrew logo goes to [PabloMK7](http://gbatemp.net/members/pablomk7.345712/).
